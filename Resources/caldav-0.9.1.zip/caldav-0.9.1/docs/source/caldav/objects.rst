:mod:`objects` -- Object definitions
====================================

.. automodule:: caldav.objects
   :synopsis: Base DAVObject class
   :members: 
